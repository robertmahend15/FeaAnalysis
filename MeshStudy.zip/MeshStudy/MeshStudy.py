import matplotlib.pyplot as plt
import matplotlib.colors
import matplotlib as mpl
import numpy as np
import sympy as sp
import matplotlib.cm as cm

def scos(x): return sp.N(sp.cos(x))
def ssin(x): return sp.N(sp.sin(x))

f = open("1x1.msh", "r")

# Determine number of nodes
nnodes = f.readline().splitlines()
nnodes = int(nnodes[0])
print("Number of nodes:", nnodes)
# Create vector of nodal displacements
# u_x = [sp.symbols('ux_%d' % i) for i in range(1, nnodes+1)]
# u_y = [sp.symbols('uy_%d' % i) for i in range(1, nnodes+1)]
# u_vec = []
#
#
# for i in range(nnodes):
#     u_vec.append(u_x[i])
#     u_vec.append(u_y[i])
# u = sp.Matrix(u_vec)

# Extract node data
nodes_mat = np.zeros((nnodes, 6))
for i in range(nnodes):
    node_i = f.readline().splitlines()
    node_i = node_i[0].split()  # string data
    node_i = [float(numeric_string) for numeric_string in node_i]  # integer data
    nodes_mat[i,:] = node_i

force_mat = nodes_mat[:,4:6]
force = []
for i in range(nnodes):
    for j in range(2):
        force.append(int(force_mat[i][j]))
force = sp.Matrix(force).reshape(2*nnodes,1)

position_mat = nodes_mat[:,0:2]
position = []
for i in range(nnodes):
    for j in range(2):
        position.append(int(position_mat[i][j]))
position = sp.Matrix(position).reshape(2*nnodes,1)
# x_old = position[0:len(position):2]
# x_old.append(x_old[0])
# y_old = position[1:len(position):2]
# y_old.append(y_old[0])

# Determine number of elements
nels = f.readline().splitlines()
nels = int(nels[0])

# Extract element data
els_mat = np.zeros((nels, 7))
for i in range(nels):
    el_i = f.readline().splitlines()
    el_i = el_i[0].split()  # string data
    el_i = [float(numeric_string) for numeric_string in el_i]  # integer data
    els_mat[i, :] = el_i
E_mat = els_mat[:,4]
nu_mat = els_mat[:,5]
h_mat = els_mat[:,6]


k_global = np.zeros((2*nnodes, 2*nnodes))
for i in range(nels):
    nodes_el = els_mat[i,0:4]
    n0 = int(nodes_el[0])
    n1 = int(nodes_el[1])
    n2 = int(nodes_el[2])
    n3 = int(nodes_el[3])
    nodes_el = [int(number) for number in nodes_el]
    node_pos = position_mat[nodes_el,:]
    node_dimension_max = np.amax(node_pos, axis=0)
    node_dimension_min = np.amin(node_pos, axis=0)
    node_dimension = node_dimension_max - node_dimension_min
    gamma = node_dimension[0] / node_dimension[1]

    nu = nu_mat[i]
    E = E_mat[i]
    h = h_mat[i]

    psi_1 = (1+nu)*gamma
    psi_2 = (1-3*nu)*gamma
    psi_3 = 2+(1-nu)*gamma**2
    psi_4 = 2*gamma**2 + (1-nu)
    psi_5 = (1-nu)*gamma**2-4
    psi_6 = (1-nu)*gamma**2-1
    psi_7 = 4*gamma**2-(1-nu)
    psi_8 = gamma**2-(1-nu)

    # Construct elemental matrix
    # k_el = np.array([[4*psi_3, 3*psi_1, 2*psi_5, -3*psi_2, -2*psi_3, -3*psi_1, -4*psi_6, 3*psi_2],
    #                  [3*psi_1, 4*psi_4, 3*psi_2, 4*psi_3, -3*psi_1, -2*psi_4, -3*psi_2, -2*psi_7],
    #                  [2*psi_5, 3*psi_2, 4*psi_8, -3*psi_1, -4*psi_3, -3*psi_2, -2*psi_3, 3*psi_1],
    #                  [-3*psi_2, 4*psi_3, -3*psi_1, 4*psi_4, 3*psi_2, -2*psi_7, 3*psi_1, -2*psi_4],
    #                  [-2*psi_3, -3*psi_1, -4*psi_3, 3*psi_2, 4*psi_3, 3*psi_1, 2*psi_5, -3*psi_2],
    #                  [-3*psi_1, -2*psi_4, -3*psi_2, -2*psi_7, 3*psi_1, 4*psi_4, 3*psi_2, 4*psi_8],
    #                  [-4*psi_6, -3*psi_2, -2*psi_3, 3*psi_1, 2*psi_5, 3*psi_2, 4*psi_3, -3*psi_1],
    #                  [3*psi_2, -2*psi_7, 3*psi_1, -2*psi_4, -3*psi_2, 4*psi_8, -3*psi_1, 4*psi_4]])
    k_el = np.array([[8+(-4*nu+4)*gamma**2, 3*(1+nu)*gamma, -8+(-2*nu+2)*gamma**2, (-3+9*nu)*gamma, -4+(2*nu-2)*gamma**2, -3*(1+nu)*gamma, 4+(4*nu-4)*gamma**2, (3-9*nu)*gamma],
                    [3*(1+nu)*gamma, 8*gamma**2-4*nu+4, (3-9*nu)*gamma, 4*gamma**2+4*nu-4, -3*(1+nu)*gamma, -4*gamma**2+2*nu-2, (-3+9*nu)*gamma, -8*gamma**2-2*nu+2],
                    [-8+(-2*nu+2)*gamma**2, (3-9*nu)*gamma, 8+(-4*nu+4)*gamma**2, -3*(1+nu)*gamma, 4+(4*nu-4)*gamma**2, (-3+9*nu)*gamma, -4+(2*nu-2)*gamma**2, 3*(1+nu)*gamma],
                    [(-3+9*nu)*gamma, 4*gamma**2+4*nu-4, -3*(1+nu)*gamma, 8*gamma**2-4*nu+4, (3-9*nu)*gamma, -8*gamma**2-2*nu+2, 3*(1+nu)*gamma, -4*gamma**2+2*nu-2],
                    [-4+(2*nu-2)*gamma**2, -3*(1+nu)*gamma, 4+(4*nu-4)*gamma**2, (3-9*nu)*gamma, 8+(-4*nu+4)*gamma**2, 3*(1+nu)*gamma, -8+(-2*nu+2)*gamma**2, (-3+9*nu)*gamma],
                    [-3*(1+nu)*gamma, -4*gamma**2+2*nu-2, (-3+9*nu)*gamma, -8*gamma**2-2*nu+2, 3*(1+nu)*gamma, 8*gamma**2-4*nu+4, (3-9*nu)*gamma, 4*gamma**2+4*nu-4],
                    [4+(4*nu-4)*gamma**2, (-3+9*nu)*gamma, -4+(2*nu-2)*gamma**2, 3*(1+nu)*gamma, -8+(-2*nu+2)*gamma**2, (3-9*nu)*gamma, 8+(-4*nu+4)*gamma**2, -3*(1+nu)*gamma],
                    [(3-9*nu)*gamma, -8*gamma**2-2*nu+2, 3*(1+nu)*gamma, -4*gamma**2+2*nu-2, (-3+9*nu)*gamma, 4*gamma**2+4*nu-4, -3*(1+nu)*gamma, 8*gamma**2-4*nu+4]])
    k_el = h*E/(24*gamma*(1-nu**2))*k_el

    # Split elemental matrix into 16 sections as shown to assemble global matrix
    # [[0 1 2 3]
    #  [4 5 6 7]
    #  [8 9 10 11]
    #  [12 13 14 15]]

    # Section 0
    k_global[2*n0, 2*n0] += k_el[0, 0]
    k_global[2*n0+1, 2*n0] += k_el[1, 0]
    k_global[2*n0, 2*n0+1] += k_el[0, 1]
    k_global[2*n0+1, 2*n0+1] += k_el[1, 1]

    # Section 1
    k_global[2*n0, 2*n1] += k_el[0, 2]
    k_global[2*n0+1, 2*n1] += k_el[1, 2]
    k_global[2*n0, 2*n1+1] += k_el[0, 3]
    k_global[2*n0+1, 2*n1+1] += k_el[1, 3]

    # Section 2
    k_global[2*n0, 2*n2] += k_el[0, 4]
    k_global[2*n0+1, 2*n2] += k_el[1, 4]
    k_global[2*n0, 2*n2+1] += k_el[0, 5]
    k_global[2*n0+1, 2*n2+1] += k_el[1, 5]

    # Section 3
    k_global[2*n0, 2*n3] += k_el[0, 6]
    k_global[2*n0+1, 2*n3] += k_el[1, 6]
    k_global[2*n0, 2*n3+1] += k_el[0, 7]
    k_global[2*n0+1, 2*n3+1] += k_el[1, 7]

    # Section 4
    k_global[2*n1, 2*n0] += k_el[2, 0]
    k_global[2*n1+1, 2*n0] += k_el[3, 0]
    k_global[2*n1, 2*n0+1] += k_el[2, 1]
    k_global[2*n1+1, 2*n0+1] += k_el[3, 1]

    # Section 5
    k_global[2*n1, 2*n1] += k_el[2, 2]
    k_global[2*n1+1, 2*n1] += k_el[3, 2]
    k_global[2*n1, 2*n1+1] += k_el[2, 3]
    k_global[2*n1+1, 2*n1+1] += k_el[3, 3]

    # Section 6
    k_global[2*n1, 2*n2] += k_el[2, 4]
    k_global[2*n1+1, 2*n2] += k_el[3, 4]
    k_global[2*n1, 2*n2+1] += k_el[2, 5]
    k_global[2*n1+1, 2*n2+1] += k_el[3, 5]

    # Section 7
    k_global[2*n1, 2*n3] += k_el[2, 6]
    k_global[2*n1+1, 2*n3] += k_el[3, 6]
    k_global[2*n1, 2*n3+1] += k_el[2, 7]
    k_global[2*n1+1, 2*n3+1] += k_el[3, 7]

    # Section 8
    k_global[2*n2, 2*n0] += k_el[4, 0]
    k_global[2*n2+1, 2*n0] += k_el[5, 0]
    k_global[2*n2, 2*n0+1] += k_el[4, 1]
    k_global[2*n2+1, 2*n0+1] += k_el[5, 1]

    # Section 9
    k_global[2*n2, 2*n1] += k_el[4, 2]
    k_global[2*n2+1, 2*n1] += k_el[5, 2]
    k_global[2*n2, 2*n1+1] += k_el[4, 3]
    k_global[2*n2+1, 2*n1+1] += k_el[5, 3]

    # Section 10
    k_global[2*n2, 2*n2] += k_el[4, 4]
    k_global[2*n2+1, 2*n2] += k_el[5, 4]
    k_global[2*n2, 2*n2+1] += k_el[4, 5]
    k_global[2*n2+1, 2*n2+1] += k_el[5, 5]

    # Section 11
    k_global[2*n2, 2*n3] += k_el[4, 6]
    k_global[2*n2+1, 2*n3] += k_el[5, 6]
    k_global[2*n2, 2*n3+1] += k_el[4, 7]
    k_global[2*n2+1, 2*n3+1] += k_el[5, 7]

    # Section 12
    k_global[2*n3, 2*n0] += k_el[6, 0]
    k_global[2*n3+1, 2*n0] += k_el[7, 0]
    k_global[2*n3, 2*n0+1] += k_el[6, 1]
    k_global[2*n3+1, 2*n0+1] += k_el[7, 1]

    # Section 13
    k_global[2*n3, 2*n1] += k_el[6, 2]
    k_global[2*n3+1, 2*n1] += k_el[7, 2]
    k_global[2*n3, 2*n1+1] += k_el[6, 3]
    k_global[2*n3+1, 2*n1+1] += k_el[7, 3]

    # Section 14
    k_global[2*n3, 2*n2] += k_el[6, 4]
    k_global[2*n3+1, 2*n2] += k_el[7, 4]
    k_global[2*n3, 2*n2+1] += k_el[6, 5]
    k_global[2*n3+1, 2*n2+1] += k_el[7, 5]

    # Section 15
    k_global[2*n3, 2*n3] += k_el[6, 6]
    k_global[2*n3+1, 2*n3] += k_el[7, 6]
    k_global[2*n3, 2*n3+1] += k_el[6, 7]
    k_global[2*n3+1, 2*n3+1] += k_el[7, 7]


#######################################################################################################################
# APPLY BOUNDARY CONDITIONS

constraint_mat = nodes_mat[:,2:4]
constraint_vec = []
for i in range(nnodes):
    for j in range(2):
        constraint_vec.append(int(constraint_mat[i][j]))
index_del = [i for i in range(len(constraint_vec)) if constraint_vec[i] == 1]
index_rep = [i for i in range(len(constraint_vec)) if constraint_vec[i] == 0]

k_constrained = np.delete(k_global,index_del,0)
k_constrained = np.delete(k_constrained,index_del,1)

for i in range(len(index_del)-1,-1,-1):
    ind = index_del[i]
    force.row_del(ind)

# # Find Displacements
k_constrained_inv = np.linalg.inv(k_constrained)
u_constrained = k_constrained_inv.dot(force)


# Displacement is zero at the indexes where system is constrained
u_vec = np.zeros(nnodes*2)
for i in range(len(index_rep)):
    ind = index_rep[i]
    u_vec[ind] = float(u_constrained[i])
ux_vec = u_vec[0::2]
uy_vec = u_vec[1::2]

u_max = np.max(u_vec)
print("Displacements: ", u_vec)
print("Maximum nodal displacement is:", u_max)

# Calculate forces (N) on every node
force = np.array(force, dtype=float).reshape(2*nnodes, 1)
force_resultant = force[index_del]
node_x = ['ux_%d' % i for i in range(1, nnodes+1)]
node_y = ['uy_%d' % i for i in range(1, nnodes+1)]
node_vec = []
for i in range(nnodes):
    node_vec.append(node_x[i])
    node_vec.append(node_y[i])

for i in range(len(index_del)):
    print("Resultant force for node {} is: {} Newtons".format(node_vec[i], round(force_resultant[i], 2)))

num = 100

# Calculate strain and stress
u_x_matrix = np.zeros((num, 1))
u_y_matrix = np.zeros((num, 1))
eps_x_matrix = np.zeros((num, 1))
eps_y_matrix = np.zeros((num, 1))
eps_xy_matrix = np.zeros((num, 1))
sigma_x_matrix = np.zeros((num, 1))
sigma_y_matrix = np.zeros((num, 1))
sigma_xy_matrix = np.zeros((num, 1))
w_e = 0;


x_max = 0
y_max = 0
sigma_v_max = 0
for i in range(nels):
    el_num = i + 1
    nodes_el = els_mat[i, 0:4]
    n0 = int(nodes_el[0])
    n1 = int(nodes_el[1])
    n2 = int(nodes_el[2])
    n3 = int(nodes_el[3])
    nu = nu_mat[i]
    E = E_mat[i]
    h = h_mat[i]
    nodes_el = [int(number) for number in nodes_el]
    node_pos = position_mat[nodes_el,:]
    node_dimension_max = np.amax(node_pos, axis=0)
    node_dimension_min = np.amin(node_pos, axis=0)
    node_dimension = node_dimension_max - node_dimension_min
    gamma = node_dimension[0] / node_dimension[1]
    a = node_dimension[0]
    b = node_dimension[1]
    u_x1 = u_vec[(n0*2)]
    u_x2 = u_vec[(n1*2)]
    u_x3 = u_vec[(n2*2)]
    u_x4 = u_vec[(n3*2)]
    u_y1 = u_vec[(n0*2)+1]
    u_y2 = u_vec[(n1*2)+1]
    u_y3 = u_vec[(n2*2)+1]
    u_y4 = u_vec[(n3*2)+1]
    x1 = position_mat[n0, 0] + u_x1
    y1 = position_mat[n0, 1] + u_y1
    x2 = position_mat[n1, 0] + u_x2
    y2 = position_mat[n1, 1] + u_y2
    x3 = position_mat[n2, 0] + u_x3
    y3 = position_mat[n2, 1] + u_y3
    x4 = position_mat[n3, 0] + u_x4
    y4 = position_mat[n3, 1] + u_y4

    x_values = np.linspace(x1, x2, num)
    val1 = np.max(x_values)
    if val1 > x_max:
        x_max = val1
    y_values = np.linspace(y1, y3, num)
    val2 = np.max(y_values)
    if val2 > y_max:
        y_max = val2
    u_x = np.zeros((x_values.size, y_values.size))
    u_y = np.zeros((x_values.size, y_values.size))
    eps_x = np.zeros((x_values.size, y_values.size))
    eps_y = np.zeros((x_values.size, y_values.size))
    eps_xy = np.zeros((x_values.size, y_values.size))
    sigma_x = np.zeros((x_values.size, y_values.size))
    sigma_y = np.zeros((x_values.size, y_values.size))
    sigma_xy = np.zeros((x_values.size, y_values.size))
    for i in range(x_values.size):
        for j in range(y_values.size):
            u_x[j,i] = u_x1 + ((u_x2 - u_x1)/a)*(x_values[i]-x1) + ((u_x4 + ((u_x3-u_x4)/a)*(x_values[i]-x1) - (u_x1 + ((u_x2 - u_x1)/a)*(x_values[i]-x1)))/b) * (y_values[j]-y1)
            u_y[j,i] = u_y1 + ((u_y4 - u_y1)/b)*(y_values[j]-y1) + ((u_y2 + ((u_y3-u_y2)/b)*(y_values[j]-y1) - (u_y1 + ((u_y4 - u_y1)/b)*(y_values[j]-y1)))/a) * (x_values[i]-x1)

            eps_x[j,i] = (u_x2 - u_x1)/a + ((((u_x3 - u_x4)/a) - ((u_x2 - u_x1)/a))/b)*(y_values[j] - y1)
            eps_y[j,i] = (u_y4 - u_y1)/b + ((((u_y3 - u_y2)/b) - ((u_y4 - u_y1)/b))/a)*(x_values[i] - x1)
            eps_xy[j,i] = (0.5 * (((u_x4 - u_x1)/b) + ((u_y2 - u_y1)/a))) + ((u_x1 + u_x3 - u_x2 - u_x4)/(2*a*b))*(x_values[i]-x1) + ((u_y1 + u_y3 - u_y2 - u_y4)/(2*a*b))*(y_values[j]-y1)

            Lambda = (E*nu)/((1+nu)*(1-2*nu))
            mu = E/(2*(1+nu))
            sigma_x[j,i] = Lambda*(eps_x[j, i] + eps_y[j, i]) + (2*mu*eps_x[j, i])
            sigma_y[j,i] = Lambda*(eps_x[j, i] + eps_y[j, i]) + (2*mu*eps_y[j, i])
            sigma_xy[j,i] = 2*mu*eps_xy[j, i]

            w_e += (a/num)*(b/num)*(h/2)*(sigma_x[j,i] * eps_x[j,i] + sigma_y[j,i]*eps_y[j,i] + 2*sigma_xy[j,i]*eps_xy[j,i])
            sigma_v = np.sqrt((-(sigma_x*sigma_y)+sigma_x**2+sigma_y**2+3*(sigma_xy**2))/2)
            if np.max(sigma_v) > sigma_v_max:
                sigma_v_max = np.max(sigma_v)
    u_x_matrix = np.hstack((u_x_matrix,u_x))
    u_y_matrix = np.hstack((u_y_matrix,u_y))
    eps_x_matrix = np.hstack((eps_x_matrix,eps_x))
    eps_y_matrix = np.hstack((eps_y_matrix, eps_y))
    eps_xy_matrix = np.hstack((eps_xy_matrix, eps_xy))
    sigma_x_matrix = np.hstack((sigma_x_matrix, sigma_x))
    sigma_y_matrix = np.hstack((sigma_y_matrix, sigma_y))
    sigma_xy_matrix = np.hstack((sigma_xy_matrix, sigma_xy))

print("Strain Energy is:", w_e)
print("Maxim Von Mises Stress is:", sigma_v_max)

u_x_global = np.zeros((1, int(np.sqrt(nels)*num)))
u_y_global = np.zeros((1, int(np.sqrt(nels)*num)))
eps_x_global = np.zeros((1, int(np.sqrt(nels)*num)))
eps_y_global = np.zeros((1, int(np.sqrt(nels)*num)))
eps_xy_global = np.zeros((1, int(np.sqrt(nels)*num)))
sigma_x_global = np.zeros((1, int(np.sqrt(nels)*num)))
sigma_y_global = np.zeros((1, int(np.sqrt(nels)*num)))
sigma_xy_global = np.zeros((1, int(np.sqrt(nels)*num)))

for i in range(int(np.sqrt(nels))):
    start = int(np.sqrt(nels)*num*i+1)
    end = int(np.sqrt(nels)*num*(i+1))
    u_x_append = u_x_matrix[:, start:end+1]
    u_x_global = np.vstack((u_x_global, u_x_append))
    u_y_append = u_y_matrix[:, start:end+1]
    u_y_global = np.vstack((u_y_global, u_y_append))
    eps_x_append = eps_x_matrix[:, start:end+1]
    eps_x_global = np.vstack((eps_x_global, eps_x_append))
    eps_y_append = eps_y_matrix[:, start:end+1]
    eps_y_global = np.vstack((eps_y_global, eps_y_append))
    eps_xy_append = eps_xy_matrix[:, start:end+1]
    eps_xy_global = np.vstack((eps_xy_global, eps_xy_append))
    sigma_x_append = sigma_x_matrix[:, start:end+1]
    sigma_x_global = np.vstack((sigma_x_global, sigma_x_append))
    sigma_y_append = sigma_y_matrix[:, start:end+1]
    sigma_y_global = np.vstack((sigma_y_global, sigma_y_append))
    sigma_xy_append = sigma_xy_matrix[:, start:end+1]
    sigma_xy_global = np.vstack((sigma_xy_global, sigma_xy_append))

u_x_global= u_x_global[1:,:]
u_y_global= u_y_global[1:,:]
eps_x_global= eps_x_global[1:,:]
eps_y_global= eps_y_global[1:,:]
eps_xy_global= eps_xy_global[1:,:]
sigma_x_global= sigma_x_global[1:,:]
sigma_y_global= sigma_y_global[1:,:]
sigma_xy_global= sigma_xy_global[1:,:]
#######################################################################################################################
# PLOTTING


plt.title('Deformation Subject to Loading (displ. magnified 200x)')
plt.xlabel('x (m)')
plt.ylabel('y (m)')

plotlines = []
stress_vec = []
max_stress = 0
min_stress = 0

for i in range(nels):
    nodes_el = els_mat[i, 0:4]
    n0 = int(nodes_el[0])
    n1 = int(nodes_el[1])
    n2 = int(nodes_el[2])
    n3 = int(nodes_el[3])
    position_old = np.zeros((5,2))
    position_old[0, :] = position_mat[n0, :]
    position_old[1, :] = position_mat[n1, :]
    position_old[2, :] = position_mat[n2, :]
    position_old[3, :] = position_mat[n3, :]
    position_old[4, :] = position_mat[n0, :]
    displ = np.zeros((5,2))
    displ[0, :] = [ux_vec[n0], uy_vec[n0]]
    displ[1, :] = [ux_vec[n1], uy_vec[n1]]
    displ[2, :] = [ux_vec[n2], uy_vec[n2]]
    displ[3, :] = [ux_vec[n3], uy_vec[n3]]
    displ[4, :] = [ux_vec[n0], uy_vec[n0]]
    displ_x = displ[:,0]
    displ_y = displ[:,1]
    x_old = position_old[:, 0]
    x_new = x_old + 200*displ_x

    y_old = position_old[:, 1]
    y_new = y_old + 200*displ_y


    plt.plot(x_old, y_old, '-', color='k')
    plt.plot(x_new, y_new, '-', color='g')

# plt.plot(x_new, y_new, '-', color='b')
x_values = np.linspace(0, x_max, num*int(np.sqrt(nels)))
y_values = np.linspace(0, y_max, num*int(np.sqrt(nels)))

# u_x Contour Plot
fig, (ax1, ax2) = plt.subplots(2, 1, gridspec_kw={'height_ratios': [10, 1]})
ax1.set_title('X-Displacement Contour Plot')
ax1.set(xlabel='x (m)', ylabel='y (m)')
color_vector = u_x_global / np.max(abs(u_x_global))
cpf = ax1.contourf(x_values, y_values, color_vector, cmap=cm.cool)
line_colors = ['black' for l in cpf.levels]

cmap = mpl.cm.cool
norm = mpl.colors.Normalize(vmin=np.min(u_x_global), vmax=np.max(u_x_global))
fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), cax=ax2, orientation='horizontal', label='X Displacement (m)')

# u_y Contour Plot
fig, (ax3, ax4) = plt.subplots(2, 1, gridspec_kw={'height_ratios': [10, 1]})
ax3.set_title('Y-Displacement Contour Plot')
ax3.set(xlabel='x (m)', ylabel='y (m)')
# Normalize color bar
color_vector = u_y_global / np.max(abs(u_y_global))
cpf = ax3.contourf(x_values, y_values, color_vector, cmap=cm.cool)
# show color bar for stresses
cmap = mpl.cm.cool
norm = mpl.colors.Normalize(vmin=np.min(u_y_global), vmax=np.max(u_y_global))
fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), cax=ax4, orientation='horizontal', label='Y Displacement (m)')
plt.show()

# eps_x
fig, (ax5, ax6) = plt.subplots(2, 1, gridspec_kw={'height_ratios': [10, 1]})
ax5.set_title('X-Strain Contour Plot')
ax5.set(xlabel='x (m)', ylabel='y (m)')
# Normalize color bar
color_vector = eps_x_global / np.max(abs(eps_x_global))
cpf = ax5.contourf(x_values, y_values, color_vector, cmap=cm.cool)
# show color bar for stresses
cmap = mpl.cm.cool
norm = mpl.colors.Normalize(vmin=np.min(eps_x_global), vmax=np.max(eps_x_global))
fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), cax=ax6, orientation='horizontal', label='X Strain (~)')
plt.show()

eps_y
fig, (ax7, ax8) = plt.subplots(2, 1, gridspec_kw={'height_ratios': [10, 1]})
ax7.set_title('Y-Strain Contour Plot')
ax7.set(xlabel='x (m)', ylabel='y (m)')
# Normalize color bar
color_vector = eps_y_global / np.max(abs(eps_y_global))
cpf = ax7.contourf(x_values, y_values, color_vector, cmap=cm.cool)
# show color bar for stresses
cmap = mpl.cm.cool
norm = mpl.colors.Normalize(vmin=np.min(eps_y_global), vmax=np.max(eps_y_global))
fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), cax=ax8, orientation='horizontal', label='Y Strain (~)')
plt.show()

# eps_xy
fig, (ax9, ax10) = plt.subplots(2, 1, gridspec_kw={'height_ratios': [10, 1]})
ax9.set_title('XY-Strain Contour Plot')
ax9.set(xlabel='x (m)', ylabel='y (m)')
# Normalize color bar
color_vector = eps_xy_global / np.max(abs(eps_xy_global))
cpf = ax9.contourf(x_values, y_values, color_vector, cmap=cm.cool)
# show color bar for stresses
cmap = mpl.cm.cool
norm = mpl.colors.Normalize(vmin=np.min(eps_xy_global), vmax=np.max((eps_xy_global)))
fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), cax=ax10, orientation='horizontal', label='XY Strain (~)')
plt.show()

# sigma_x
fig, (ax11, ax12) = plt.subplots(2, 1, gridspec_kw={'height_ratios': [10, 1]})
ax11.set_title('X-Stress Contour Plot')
ax11.set(xlabel='x (m)', ylabel='y (m)')
# Normalize color bar
color_vector = sigma_x_global / np.max(sigma_x_global)
cpf = ax11.contourf(x_values, y_values, color_vector, cmap=cm.cool)
# show color bar for stresses
cmap = mpl.cm.cool
norm = mpl.colors.Normalize(vmin=np.min(sigma_x_global), vmax=np.max(sigma_x_global))
fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), cax=ax12, orientation='horizontal', label=' X Stress (Pa)')
plt.show()

# sigma_y
fig, (ax13, ax14) = plt.subplots(2, 1, gridspec_kw={'height_ratios': [10, 1]})
ax13.set_title('Y-Stress Contour Plot')
ax13.set(xlabel='x (m)', ylabel='y (m)')
# Normalize color bar
color_vector = sigma_y_global / np.max(sigma_y_global)
cpf = ax13.contourf(x_values, y_values, color_vector, cmap=cm.cool)
# show color bar for stresses
cmap = mpl.cm.cool
norm = mpl.colors.Normalize(vmin=np.min(sigma_y_global), vmax=np.max(sigma_y_global))
fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), cax=ax14, orientation='horizontal', label='Y Stress (Pa)')
plt.show()

# sigma_xy
fig, (ax15, ax16) = plt.subplots(2, 1, gridspec_kw={'height_ratios': [10, 1]})
ax15.set_title('XY-Stress Contour Plot')
ax15.set(xlabel='x (m)', ylabel='y (m)')
# Normalize color bar
color_vector = sigma_xy_global / np.max(abs(sigma_xy_global))
cpf = ax15.contourf(x_values, y_values, color_vector, cmap=cm.cool)
# show color bar for stresses
cmap = mpl.cm.cool
norm = mpl.colors.Normalize(vmin=np.min(sigma_xy_global), vmax=np.max(sigma_xy_global))
fig.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), cax=ax16, orientation='horizontal', label='XY Stress (Pa)')
plt.show()

print("end")